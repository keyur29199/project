﻿namespace login
{
    partial class Cancel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblc = new System.Windows.Forms.Label();
            this.btnc = new System.Windows.Forms.Button();
            this.cbvia = new System.Windows.Forms.ComboBox();
            this.cbd = new System.Windows.Forms.ComboBox();
            this.cbs = new System.Windows.Forms.ComboBox();
            this.lblvia = new System.Windows.Forms.Label();
            this.txtsno = new System.Windows.Forms.TextBox();
            this.lblsno = new System.Windows.Forms.Label();
            this.txtfare = new System.Windows.Forms.TextBox();
            this.lblfare = new System.Windows.Forms.Label();
            this.cbct = new System.Windows.Forms.ComboBox();
            this.lblct = new System.Windows.Forms.Label();
            this.lbld = new System.Windows.Forms.Label();
            this.lbls = new System.Windows.Forms.Label();
            this.jd3 = new System.Windows.Forms.ComboBox();
            this.jd2 = new System.Windows.Forms.ComboBox();
            this.jd1 = new System.Windows.Forms.ComboBox();
            this.lblj = new System.Windows.Forms.Label();
            this.txtdt = new System.Windows.Forms.TextBox();
            this.lbldt = new System.Windows.Forms.Label();
            this.lbltnm = new System.Windows.Forms.Label();
            this.cbtno = new System.Windows.Forms.ComboBox();
            this.lbltn = new System.Windows.Forms.Label();
            this.lblnm = new System.Windows.Forms.Label();
            this.txtnm = new System.Windows.Forms.TextBox();
            this.lblpid = new System.Windows.Forms.Label();
            this.txtpid = new System.Windows.Forms.TextBox();
            this.cbtnm = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // lblc
            // 
            this.lblc.AutoSize = true;
            this.lblc.BackColor = System.Drawing.Color.Transparent;
            this.lblc.Font = new System.Drawing.Font("Gabriola", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblc.ForeColor = System.Drawing.Color.Blue;
            this.lblc.Location = new System.Drawing.Point(367, -18);
            this.lblc.Name = "lblc";
            this.lblc.Size = new System.Drawing.Size(360, 147);
            this.lblc.TabIndex = 0;
            this.lblc.Text = "Cancelation";
            // 
            // btnc
            // 
            this.btnc.BackColor = System.Drawing.Color.LightSalmon;
            this.btnc.Font = new System.Drawing.Font("Mongolian Baiti", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnc.Location = new System.Drawing.Point(742, 473);
            this.btnc.Name = "btnc";
            this.btnc.Size = new System.Drawing.Size(187, 48);
            this.btnc.TabIndex = 3;
            this.btnc.Text = "Cancel";
            this.btnc.UseVisualStyleBackColor = false;
            this.btnc.Click += new System.EventHandler(this.btnc_Click);
            // 
            // cbvia
            // 
            this.cbvia.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbvia.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbvia.ForeColor = System.Drawing.SystemColors.Desktop;
            this.cbvia.FormattingEnabled = true;
            this.cbvia.Items.AddRange(new object[] {
            "DIBRUGARH TOWN",
            "JAMMU TAWI",
            "PURI",
            "HOWRAH JN",
            "NEW DELHI",
            "AHMEDABAD JN",
            "HOWRAH JN",
            "ANAND VIHAR TRM",
            "BANGALORE CITY JN",
            "FIROZPUR CANTT"});
            this.cbvia.Location = new System.Drawing.Point(214, 311);
            this.cbvia.Name = "cbvia";
            this.cbvia.Size = new System.Drawing.Size(264, 29);
            this.cbvia.TabIndex = 45;
            // 
            // cbd
            // 
            this.cbd.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbd.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbd.ForeColor = System.Drawing.SystemColors.Desktop;
            this.cbd.FormattingEnabled = true;
            this.cbd.Items.AddRange(new object[] {
            "DIBRUGARH TOWN",
            "JAMMU TAWI",
            "PURI",
            "HOWRAH JN",
            "NEW DELHI",
            "GUWAHATI",
            "DANAPUR",
            "MUMBAI",
            "PUNE"});
            this.cbd.Location = new System.Drawing.Point(674, 252);
            this.cbd.Name = "cbd";
            this.cbd.Size = new System.Drawing.Size(255, 29);
            this.cbd.TabIndex = 44;
            // 
            // cbs
            // 
            this.cbs.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbs.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbs.ForeColor = System.Drawing.SystemColors.Desktop;
            this.cbs.FormattingEnabled = true;
            this.cbs.Items.AddRange(new object[] {
            "NEW DELHI",
            "PUNE",
            "YESVANTPUR JN",
            "MUMBAI CST",
            "PURI",
            "AHMEDABAD JN",
            "HOWRAH JN",
            "ANAND VIHAR TRM",
            "BANGALORE CITY JN",
            "FIROZPUR CANT"});
            this.cbs.Location = new System.Drawing.Point(214, 257);
            this.cbs.Name = "cbs";
            this.cbs.Size = new System.Drawing.Size(263, 29);
            this.cbs.TabIndex = 43;
            // 
            // lblvia
            // 
            this.lblvia.AutoSize = true;
            this.lblvia.BackColor = System.Drawing.Color.Transparent;
            this.lblvia.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblvia.ForeColor = System.Drawing.SystemColors.Desktop;
            this.lblvia.Location = new System.Drawing.Point(70, 314);
            this.lblvia.Name = "lblvia";
            this.lblvia.Size = new System.Drawing.Size(55, 21);
            this.lblvia.TabIndex = 42;
            this.lblvia.Text = "Via :";
            // 
            // txtsno
            // 
            this.txtsno.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsno.ForeColor = System.Drawing.SystemColors.Desktop;
            this.txtsno.Location = new System.Drawing.Point(673, 420);
            this.txtsno.Name = "txtsno";
            this.txtsno.Size = new System.Drawing.Size(256, 31);
            this.txtsno.TabIndex = 41;
            // 
            // lblsno
            // 
            this.lblsno.AutoSize = true;
            this.lblsno.BackColor = System.Drawing.Color.Transparent;
            this.lblsno.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsno.ForeColor = System.Drawing.SystemColors.Desktop;
            this.lblsno.Location = new System.Drawing.Point(505, 430);
            this.lblsno.Name = "lblsno";
            this.lblsno.Size = new System.Drawing.Size(100, 21);
            this.lblsno.TabIndex = 40;
            this.lblsno.Text = "Seat No. :";
            // 
            // txtfare
            // 
            this.txtfare.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtfare.ForeColor = System.Drawing.SystemColors.Desktop;
            this.txtfare.Location = new System.Drawing.Point(214, 427);
            this.txtfare.Name = "txtfare";
            this.txtfare.Size = new System.Drawing.Size(263, 31);
            this.txtfare.TabIndex = 39;
            // 
            // lblfare
            // 
            this.lblfare.AutoSize = true;
            this.lblfare.BackColor = System.Drawing.Color.Transparent;
            this.lblfare.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblfare.ForeColor = System.Drawing.SystemColors.Desktop;
            this.lblfare.Location = new System.Drawing.Point(70, 430);
            this.lblfare.Name = "lblfare";
            this.lblfare.Size = new System.Drawing.Size(114, 21);
            this.lblfare.TabIndex = 38;
            this.lblfare.Text = "Fare (Rs.) :";
            // 
            // cbct
            // 
            this.cbct.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbct.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbct.ForeColor = System.Drawing.SystemColors.Desktop;
            this.cbct.FormattingEnabled = true;
            this.cbct.Items.AddRange(new object[] {
            "|| Ac Seat",
            "||| Ac Seat",
            " Ac Chair Seat",
            "| Class Seat",
            "|| Class Seat",
            "Genral Seat"});
            this.cbct.Location = new System.Drawing.Point(214, 371);
            this.cbct.Name = "cbct";
            this.cbct.Size = new System.Drawing.Size(264, 29);
            this.cbct.TabIndex = 37;
            // 
            // lblct
            // 
            this.lblct.AutoSize = true;
            this.lblct.BackColor = System.Drawing.Color.Transparent;
            this.lblct.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblct.ForeColor = System.Drawing.SystemColors.Desktop;
            this.lblct.Location = new System.Drawing.Point(70, 374);
            this.lblct.Name = "lblct";
            this.lblct.Size = new System.Drawing.Size(123, 21);
            this.lblct.TabIndex = 36;
            this.lblct.Text = "Class Type :";
            // 
            // lbld
            // 
            this.lbld.AutoSize = true;
            this.lbld.BackColor = System.Drawing.Color.Transparent;
            this.lbld.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbld.ForeColor = System.Drawing.SystemColors.Desktop;
            this.lbld.Location = new System.Drawing.Point(503, 257);
            this.lbld.Name = "lbld";
            this.lbld.Size = new System.Drawing.Size(128, 21);
            this.lbld.TabIndex = 35;
            this.lbld.Text = "Destination :";
            // 
            // lbls
            // 
            this.lbls.AutoSize = true;
            this.lbls.BackColor = System.Drawing.Color.Transparent;
            this.lbls.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbls.ForeColor = System.Drawing.SystemColors.Desktop;
            this.lbls.Location = new System.Drawing.Point(70, 260);
            this.lbls.Name = "lbls";
            this.lbls.Size = new System.Drawing.Size(85, 21);
            this.lbls.TabIndex = 34;
            this.lbls.Text = "Source :";
            // 
            // jd3
            // 
            this.jd3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.jd3.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jd3.ForeColor = System.Drawing.SystemColors.Desktop;
            this.jd3.FormattingEnabled = true;
            this.jd3.Items.AddRange(new object[] {
            "2019",
            "2020",
            "2021",
            "2022",
            "2023",
            "2024",
            "2025",
            "2026",
            "2027",
            "2028",
            "2029",
            "2030"});
            this.jd3.Location = new System.Drawing.Point(838, 366);
            this.jd3.Name = "jd3";
            this.jd3.Size = new System.Drawing.Size(91, 29);
            this.jd3.TabIndex = 33;
            // 
            // jd2
            // 
            this.jd2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.jd2.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jd2.ForeColor = System.Drawing.SystemColors.Desktop;
            this.jd2.FormattingEnabled = true;
            this.jd2.Items.AddRange(new object[] {
            "JAN",
            "FEB",
            "MAR",
            "APR",
            "MAY",
            "JUN",
            "JULY",
            "AUG",
            "SEP",
            "OCT",
            "NOV",
            "DES"});
            this.jd2.Location = new System.Drawing.Point(744, 366);
            this.jd2.Name = "jd2";
            this.jd2.Size = new System.Drawing.Size(88, 29);
            this.jd2.TabIndex = 32;
            // 
            // jd1
            // 
            this.jd1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.jd1.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jd1.ForeColor = System.Drawing.SystemColors.Desktop;
            this.jd1.FormattingEnabled = true;
            this.jd1.Items.AddRange(new object[] {
            "01",
            "02",
            "03",
            "04",
            "05",
            "06",
            "07",
            "08",
            "09",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24",
            "25",
            "26",
            "27",
            "28",
            "29",
            "30",
            "31"});
            this.jd1.Location = new System.Drawing.Point(675, 366);
            this.jd1.Name = "jd1";
            this.jd1.Size = new System.Drawing.Size(63, 29);
            this.jd1.TabIndex = 31;
            // 
            // lblj
            // 
            this.lblj.AutoSize = true;
            this.lblj.BackColor = System.Drawing.Color.Transparent;
            this.lblj.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblj.ForeColor = System.Drawing.SystemColors.Desktop;
            this.lblj.Location = new System.Drawing.Point(501, 374);
            this.lblj.Name = "lblj";
            this.lblj.Size = new System.Drawing.Size(132, 21);
            this.lblj.TabIndex = 30;
            this.lblj.Text = "Journy Date :";
            // 
            // txtdt
            // 
            this.txtdt.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdt.ForeColor = System.Drawing.SystemColors.Desktop;
            this.txtdt.Location = new System.Drawing.Point(674, 309);
            this.txtdt.Name = "txtdt";
            this.txtdt.Size = new System.Drawing.Size(255, 31);
            this.txtdt.TabIndex = 29;
            // 
            // lbldt
            // 
            this.lbldt.AutoSize = true;
            this.lbldt.BackColor = System.Drawing.Color.Transparent;
            this.lbldt.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldt.ForeColor = System.Drawing.SystemColors.Desktop;
            this.lbldt.Location = new System.Drawing.Point(506, 314);
            this.lbldt.Name = "lbldt";
            this.lbldt.Size = new System.Drawing.Size(158, 21);
            this.lbldt.TabIndex = 28;
            this.lbldt.Text = "Depature Time :";
            // 
            // lbltnm
            // 
            this.lbltnm.AutoSize = true;
            this.lbltnm.BackColor = System.Drawing.Color.Transparent;
            this.lbltnm.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltnm.ForeColor = System.Drawing.SystemColors.Desktop;
            this.lbltnm.Location = new System.Drawing.Point(369, 199);
            this.lbltnm.Name = "lbltnm";
            this.lbltnm.Size = new System.Drawing.Size(130, 21);
            this.lbltnm.TabIndex = 26;
            this.lbltnm.Text = "Train Name :";
            // 
            // cbtno
            // 
            this.cbtno.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbtno.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbtno.ForeColor = System.Drawing.SystemColors.Desktop;
            this.cbtno.FormattingEnabled = true;
            this.cbtno.Items.AddRange(new object[] {
            "12424",
            "11077",
            "12802",
            "12864",
            "12859",
            "12801",
            "12833",
            "12307",
            "12506",
            "12295"});
            this.cbtno.Location = new System.Drawing.Point(214, 196);
            this.cbtno.Name = "cbtno";
            this.cbtno.Size = new System.Drawing.Size(146, 29);
            this.cbtno.TabIndex = 25;
            // 
            // lbltn
            // 
            this.lbltn.AutoSize = true;
            this.lbltn.BackColor = System.Drawing.Color.Transparent;
            this.lbltn.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltn.ForeColor = System.Drawing.SystemColors.Desktop;
            this.lbltn.Location = new System.Drawing.Point(68, 199);
            this.lbltn.Name = "lbltn";
            this.lbltn.Size = new System.Drawing.Size(100, 21);
            this.lbltn.TabIndex = 24;
            this.lbltn.Text = "Trail No :";
            // 
            // lblnm
            // 
            this.lblnm.AutoSize = true;
            this.lblnm.BackColor = System.Drawing.Color.Transparent;
            this.lblnm.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold);
            this.lblnm.Location = new System.Drawing.Point(369, 135);
            this.lblnm.Name = "lblnm";
            this.lblnm.Size = new System.Drawing.Size(75, 21);
            this.lblnm.TabIndex = 46;
            this.lblnm.Text = "Name :";
            // 
            // txtnm
            // 
            this.txtnm.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnm.ForeColor = System.Drawing.SystemColors.Desktop;
            this.txtnm.Location = new System.Drawing.Point(505, 132);
            this.txtnm.Name = "txtnm";
            this.txtnm.Size = new System.Drawing.Size(424, 31);
            this.txtnm.TabIndex = 47;
            // 
            // lblpid
            // 
            this.lblpid.AutoSize = true;
            this.lblpid.BackColor = System.Drawing.Color.Transparent;
            this.lblpid.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpid.ForeColor = System.Drawing.SystemColors.Desktop;
            this.lblpid.Location = new System.Drawing.Point(70, 135);
            this.lblpid.Name = "lblpid";
            this.lblpid.Size = new System.Drawing.Size(64, 21);
            this.lblpid.TabIndex = 48;
            this.lblpid.Text = "P_id :";
            // 
            // txtpid
            // 
            this.txtpid.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpid.ForeColor = System.Drawing.SystemColors.Desktop;
            this.txtpid.Location = new System.Drawing.Point(214, 132);
            this.txtpid.Name = "txtpid";
            this.txtpid.Size = new System.Drawing.Size(146, 31);
            this.txtpid.TabIndex = 49;
            // 
            // cbtnm
            // 
            this.cbtnm.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbtnm.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbtnm.ForeColor = System.Drawing.SystemColors.Desktop;
            this.cbtnm.FormattingEnabled = true;
            this.cbtnm.Items.AddRange(new object[] {
            "DIBRUGARH TOWN RAJDHANI EXPRESS",
            "JAMMU TAWI JHELUM EXPRESS",
            "PURI PURUSHOTTAM SF EXPRESS",
            "HOWRAH SF EXPRESS",
            "HOWRAH GITANJALI SF EXPRESS",
            "NEW DELHI PURUSHOTTAM SF EXPRESS",
            "HOWRAH SF EXPRESS",
            "JODHPUR SF EXPRESS",
            "GUWAHATI NORTH EAST SF EXP",
            "DANAPUR SANGHAMITRA SF EXP"});
            this.cbtnm.Location = new System.Drawing.Point(505, 191);
            this.cbtnm.Name = "cbtnm";
            this.cbtnm.Size = new System.Drawing.Size(424, 29);
            this.cbtnm.TabIndex = 50;
            // 
            // Cancel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::login.Properties.Resources.Background_Registration_Form;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(981, 540);
            this.Controls.Add(this.cbtnm);
            this.Controls.Add(this.txtpid);
            this.Controls.Add(this.lblpid);
            this.Controls.Add(this.txtnm);
            this.Controls.Add(this.lblnm);
            this.Controls.Add(this.cbvia);
            this.Controls.Add(this.cbd);
            this.Controls.Add(this.cbs);
            this.Controls.Add(this.lblvia);
            this.Controls.Add(this.txtsno);
            this.Controls.Add(this.lblsno);
            this.Controls.Add(this.txtfare);
            this.Controls.Add(this.lblfare);
            this.Controls.Add(this.cbct);
            this.Controls.Add(this.lblct);
            this.Controls.Add(this.lbld);
            this.Controls.Add(this.lbls);
            this.Controls.Add(this.jd3);
            this.Controls.Add(this.jd2);
            this.Controls.Add(this.jd1);
            this.Controls.Add(this.lblj);
            this.Controls.Add(this.txtdt);
            this.Controls.Add(this.lbldt);
            this.Controls.Add(this.lbltnm);
            this.Controls.Add(this.cbtno);
            this.Controls.Add(this.lbltn);
            this.Controls.Add(this.btnc);
            this.Controls.Add(this.lblc);
            this.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Cancel";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cancel";
            this.Load += new System.EventHandler(this.Cancel_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblc;
        private System.Windows.Forms.Button btnc;
        private System.Windows.Forms.ComboBox cbvia;
        private System.Windows.Forms.ComboBox cbd;
        private System.Windows.Forms.ComboBox cbs;
        private System.Windows.Forms.Label lblvia;
        private System.Windows.Forms.TextBox txtsno;
        private System.Windows.Forms.Label lblsno;
        private System.Windows.Forms.TextBox txtfare;
        private System.Windows.Forms.Label lblfare;
        private System.Windows.Forms.ComboBox cbct;
        private System.Windows.Forms.Label lblct;
        private System.Windows.Forms.Label lbld;
        private System.Windows.Forms.Label lbls;
        private System.Windows.Forms.ComboBox jd3;
        private System.Windows.Forms.ComboBox jd2;
        private System.Windows.Forms.ComboBox jd1;
        private System.Windows.Forms.Label lblj;
        private System.Windows.Forms.TextBox txtdt;
        private System.Windows.Forms.Label lbldt;
        private System.Windows.Forms.Label lbltnm;
        private System.Windows.Forms.ComboBox cbtno;
        private System.Windows.Forms.Label lbltn;
        private System.Windows.Forms.Label lblnm;
        private System.Windows.Forms.TextBox txtnm;
        private System.Windows.Forms.Label lblpid;
        private System.Windows.Forms.TextBox txtpid;
        private System.Windows.Forms.ComboBox cbtnm;
    }
}