﻿namespace login
{
    partial class Customer_Care
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblcc = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblnm = new System.Windows.Forms.Label();
            this.lblcno = new System.Windows.Forms.Label();
            this.lbladd = new System.Windows.Forms.Label();
            this.lblc = new System.Windows.Forms.Label();
            this.txtnm = new System.Windows.Forms.TextBox();
            this.txtcno = new System.Windows.Forms.TextBox();
            this.txta = new System.Windows.Forms.TextBox();
            this.btnsave = new System.Windows.Forms.Button();
            this.richtxtc = new System.Windows.Forms.RichTextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblcc
            // 
            this.lblcc.AutoSize = true;
            this.lblcc.BackColor = System.Drawing.Color.Transparent;
            this.lblcc.Font = new System.Drawing.Font("Gabriola", 36F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.lblcc.ForeColor = System.Drawing.Color.White;
            this.lblcc.Location = new System.Drawing.Point(250, -17);
            this.lblcc.Name = "lblcc";
            this.lblcc.Size = new System.Drawing.Size(331, 110);
            this.lblcc.TabIndex = 1;
            this.lblcc.Text = "Customer Care";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::login.Properties.Resources.images__1_;
            this.pictureBox1.Location = new System.Drawing.Point(12, 96);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(424, 413);
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // lblnm
            // 
            this.lblnm.AutoSize = true;
            this.lblnm.BackColor = System.Drawing.Color.Transparent;
            this.lblnm.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold);
            this.lblnm.Location = new System.Drawing.Point(459, 83);
            this.lblnm.Name = "lblnm";
            this.lblnm.Size = new System.Drawing.Size(75, 21);
            this.lblnm.TabIndex = 3;
            this.lblnm.Text = "Name :";
            // 
            // lblcno
            // 
            this.lblcno.AutoSize = true;
            this.lblcno.BackColor = System.Drawing.Color.Transparent;
            this.lblcno.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold);
            this.lblcno.Location = new System.Drawing.Point(459, 157);
            this.lblcno.Name = "lblcno";
            this.lblcno.Size = new System.Drawing.Size(131, 21);
            this.lblcno.TabIndex = 4;
            this.lblcno.Text = "Contect No. :";
            // 
            // lbladd
            // 
            this.lbladd.AutoSize = true;
            this.lbladd.BackColor = System.Drawing.Color.Transparent;
            this.lbladd.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold);
            this.lbladd.Location = new System.Drawing.Point(460, 234);
            this.lbladd.Name = "lbladd";
            this.lbladd.Size = new System.Drawing.Size(96, 21);
            this.lbladd.TabIndex = 5;
            this.lbladd.Text = "Address :";
            // 
            // lblc
            // 
            this.lblc.AutoSize = true;
            this.lblc.BackColor = System.Drawing.Color.Transparent;
            this.lblc.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold);
            this.lblc.Location = new System.Drawing.Point(459, 314);
            this.lblc.Name = "lblc";
            this.lblc.Size = new System.Drawing.Size(118, 21);
            this.lblc.TabIndex = 6;
            this.lblc.Text = "Complaint :";
            // 
            // txtnm
            // 
            this.txtnm.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold);
            this.txtnm.Location = new System.Drawing.Point(463, 107);
            this.txtnm.Name = "txtnm";
            this.txtnm.Size = new System.Drawing.Size(257, 31);
            this.txtnm.TabIndex = 7;
            // 
            // txtcno
            // 
            this.txtcno.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold);
            this.txtcno.Location = new System.Drawing.Point(463, 181);
            this.txtcno.Name = "txtcno";
            this.txtcno.Size = new System.Drawing.Size(257, 31);
            this.txtcno.TabIndex = 8;
            // 
            // txta
            // 
            this.txta.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold);
            this.txta.Location = new System.Drawing.Point(464, 258);
            this.txta.Name = "txta";
            this.txta.Size = new System.Drawing.Size(256, 31);
            this.txta.TabIndex = 9;
            // 
            // btnsave
            // 
            this.btnsave.BackColor = System.Drawing.Color.Yellow;
            this.btnsave.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold);
            this.btnsave.Location = new System.Drawing.Point(594, 463);
            this.btnsave.Name = "btnsave";
            this.btnsave.Size = new System.Drawing.Size(126, 46);
            this.btnsave.TabIndex = 11;
            this.btnsave.Text = "Save";
            this.btnsave.UseVisualStyleBackColor = false;
            this.btnsave.Click += new System.EventHandler(this.btnsave_Click);
            // 
            // richtxtc
            // 
            this.richtxtc.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold);
            this.richtxtc.Location = new System.Drawing.Point(463, 338);
            this.richtxtc.Name = "richtxtc";
            this.richtxtc.Size = new System.Drawing.Size(257, 116);
            this.richtxtc.TabIndex = 13;
            this.richtxtc.Text = "";
            // 
            // Customer_Care
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::login.Properties.Resources.Background_Registration_Form1;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(758, 525);
            this.Controls.Add(this.richtxtc);
            this.Controls.Add(this.btnsave);
            this.Controls.Add(this.txta);
            this.Controls.Add(this.txtcno);
            this.Controls.Add(this.txtnm);
            this.Controls.Add(this.lblc);
            this.Controls.Add(this.lbladd);
            this.Controls.Add(this.lblcno);
            this.Controls.Add(this.lblnm);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.lblcc);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Customer_Care";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Customer_Care";
            this.Load += new System.EventHandler(this.Customer_Care_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblcc;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblnm;
        private System.Windows.Forms.Label lblcno;
        private System.Windows.Forms.Label lbladd;
        private System.Windows.Forms.Label lblc;
        private System.Windows.Forms.TextBox txtnm;
        private System.Windows.Forms.TextBox txtcno;
        private System.Windows.Forms.TextBox txta;
        private System.Windows.Forms.Button btnsave;
        private System.Windows.Forms.RichTextBox richtxtc;
    }
}