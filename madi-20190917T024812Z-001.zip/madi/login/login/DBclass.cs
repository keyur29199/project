﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace login
{
    public class DBclass
    {
        public static string Cstring = @"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\madi\Documents\prodb.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
    }
}
