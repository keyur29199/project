﻿namespace login
{
    partial class PassengerDetail
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblpd = new System.Windows.Forms.Label();
            this.lblnm = new System.Windows.Forms.Label();
            this.lblage = new System.Windows.Forms.Label();
            this.lblg = new System.Windows.Forms.Label();
            this.lblcn = new System.Windows.Forms.Label();
            this.txtnm = new System.Windows.Forms.TextBox();
            this.txtage = new System.Windows.Forms.TextBox();
            this.txtcno = new System.Windows.Forms.TextBox();
            this.rbtnmale = new System.Windows.Forms.RadioButton();
            this.rbtnf = new System.Windows.Forms.RadioButton();
            this.btnok = new System.Windows.Forms.Button();
            this.lblpid = new System.Windows.Forms.Label();
            this.txtpid = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblpd
            // 
            this.lblpd.AutoSize = true;
            this.lblpd.BackColor = System.Drawing.Color.Transparent;
            this.lblpd.Font = new System.Drawing.Font("Gabriola", 36F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpd.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblpd.Location = new System.Drawing.Point(83, -1);
            this.lblpd.Name = "lblpd";
            this.lblpd.Size = new System.Drawing.Size(355, 110);
            this.lblpd.TabIndex = 0;
            this.lblpd.Text = "Passenger Detail";
            this.lblpd.Click += new System.EventHandler(this.lblpd_Click);
            // 
            // lblnm
            // 
            this.lblnm.AutoSize = true;
            this.lblnm.BackColor = System.Drawing.Color.Transparent;
            this.lblnm.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold);
            this.lblnm.ForeColor = System.Drawing.Color.Black;
            this.lblnm.Location = new System.Drawing.Point(64, 194);
            this.lblnm.Name = "lblnm";
            this.lblnm.Size = new System.Drawing.Size(81, 21);
            this.lblnm.TabIndex = 1;
            this.lblnm.Text = "Name : ";
            // 
            // lblage
            // 
            this.lblage.AutoSize = true;
            this.lblage.BackColor = System.Drawing.Color.Transparent;
            this.lblage.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold);
            this.lblage.ForeColor = System.Drawing.Color.Black;
            this.lblage.Location = new System.Drawing.Point(64, 257);
            this.lblage.Name = "lblage";
            this.lblage.Size = new System.Drawing.Size(65, 21);
            this.lblage.TabIndex = 2;
            this.lblage.Text = "Age : ";
            // 
            // lblg
            // 
            this.lblg.AutoSize = true;
            this.lblg.BackColor = System.Drawing.Color.Transparent;
            this.lblg.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold);
            this.lblg.ForeColor = System.Drawing.Color.Black;
            this.lblg.Location = new System.Drawing.Point(67, 316);
            this.lblg.Name = "lblg";
            this.lblg.Size = new System.Drawing.Size(88, 21);
            this.lblg.TabIndex = 3;
            this.lblg.Text = "Gender :";
            // 
            // lblcn
            // 
            this.lblcn.AutoSize = true;
            this.lblcn.BackColor = System.Drawing.Color.Transparent;
            this.lblcn.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold);
            this.lblcn.ForeColor = System.Drawing.Color.Black;
            this.lblcn.Location = new System.Drawing.Point(67, 371);
            this.lblcn.Name = "lblcn";
            this.lblcn.Size = new System.Drawing.Size(131, 21);
            this.lblcn.TabIndex = 4;
            this.lblcn.Text = "Contect No. :";
            // 
            // txtnm
            // 
            this.txtnm.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold);
            this.txtnm.ForeColor = System.Drawing.Color.Black;
            this.txtnm.Location = new System.Drawing.Point(218, 190);
            this.txtnm.Name = "txtnm";
            this.txtnm.Size = new System.Drawing.Size(240, 31);
            this.txtnm.TabIndex = 5;
            // 
            // txtage
            // 
            this.txtage.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold);
            this.txtage.ForeColor = System.Drawing.Color.Black;
            this.txtage.Location = new System.Drawing.Point(218, 250);
            this.txtage.Name = "txtage";
            this.txtage.Size = new System.Drawing.Size(240, 31);
            this.txtage.TabIndex = 6;
            // 
            // txtcno
            // 
            this.txtcno.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold);
            this.txtcno.ForeColor = System.Drawing.Color.Black;
            this.txtcno.Location = new System.Drawing.Point(218, 368);
            this.txtcno.Name = "txtcno";
            this.txtcno.Size = new System.Drawing.Size(240, 31);
            this.txtcno.TabIndex = 7;
            // 
            // rbtnmale
            // 
            this.rbtnmale.AutoSize = true;
            this.rbtnmale.BackColor = System.Drawing.Color.Transparent;
            this.rbtnmale.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold);
            this.rbtnmale.ForeColor = System.Drawing.Color.Black;
            this.rbtnmale.Location = new System.Drawing.Point(218, 310);
            this.rbtnmale.Name = "rbtnmale";
            this.rbtnmale.Size = new System.Drawing.Size(77, 25);
            this.rbtnmale.TabIndex = 8;
            this.rbtnmale.TabStop = true;
            this.rbtnmale.Text = "Male";
            this.rbtnmale.UseVisualStyleBackColor = false;
            // 
            // rbtnf
            // 
            this.rbtnf.AutoSize = true;
            this.rbtnf.BackColor = System.Drawing.Color.Transparent;
            this.rbtnf.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold);
            this.rbtnf.ForeColor = System.Drawing.Color.Black;
            this.rbtnf.Location = new System.Drawing.Point(301, 310);
            this.rbtnf.Name = "rbtnf";
            this.rbtnf.Size = new System.Drawing.Size(97, 25);
            this.rbtnf.TabIndex = 9;
            this.rbtnf.TabStop = true;
            this.rbtnf.Text = "Female";
            this.rbtnf.UseVisualStyleBackColor = false;
            // 
            // btnok
            // 
            this.btnok.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnok.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold);
            this.btnok.Location = new System.Drawing.Point(358, 425);
            this.btnok.Name = "btnok";
            this.btnok.Size = new System.Drawing.Size(100, 37);
            this.btnok.TabIndex = 10;
            this.btnok.Text = "OK";
            this.btnok.UseVisualStyleBackColor = false;
            this.btnok.Click += new System.EventHandler(this.btnok_Click);
            // 
            // lblpid
            // 
            this.lblpid.AutoSize = true;
            this.lblpid.BackColor = System.Drawing.Color.Transparent;
            this.lblpid.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold);
            this.lblpid.ForeColor = System.Drawing.Color.Black;
            this.lblpid.Location = new System.Drawing.Point(64, 133);
            this.lblpid.Name = "lblpid";
            this.lblpid.Size = new System.Drawing.Size(144, 21);
            this.lblpid.TabIndex = 11;
            this.lblpid.Text = "Passenger Id : ";
            // 
            // txtpid
            // 
            this.txtpid.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold);
            this.txtpid.ForeColor = System.Drawing.Color.Black;
            this.txtpid.Location = new System.Drawing.Point(218, 130);
            this.txtpid.Name = "txtpid";
            this.txtpid.Size = new System.Drawing.Size(240, 31);
            this.txtpid.TabIndex = 12;
            // 
            // PassengerDetail
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::login.Properties.Resources.Background_Registration_Form1;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(523, 485);
            this.Controls.Add(this.txtpid);
            this.Controls.Add(this.lblpid);
            this.Controls.Add(this.btnok);
            this.Controls.Add(this.rbtnf);
            this.Controls.Add(this.rbtnmale);
            this.Controls.Add(this.txtcno);
            this.Controls.Add(this.txtage);
            this.Controls.Add(this.txtnm);
            this.Controls.Add(this.lblcn);
            this.Controls.Add(this.lblg);
            this.Controls.Add(this.lblage);
            this.Controls.Add(this.lblnm);
            this.Controls.Add(this.lblpd);
            this.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "PassengerDetail";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PassengerDetail";
            this.Load += new System.EventHandler(this.PessengerDetail_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblpd;
        private System.Windows.Forms.Label lblnm;
        private System.Windows.Forms.Label lblage;
        private System.Windows.Forms.Label lblg;
        private System.Windows.Forms.Label lblcn;
        private System.Windows.Forms.TextBox txtnm;
        private System.Windows.Forms.TextBox txtage;
        private System.Windows.Forms.TextBox txtcno;
        private System.Windows.Forms.RadioButton rbtnmale;
        private System.Windows.Forms.RadioButton rbtnf;
        private System.Windows.Forms.Button btnok;
        private System.Windows.Forms.Label lblpid;
        private System.Windows.Forms.TextBox txtpid;
    }
}